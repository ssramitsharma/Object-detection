
# coding: utf-8

#  [Deep Leison dataset link](https://nihcc.app.box.com/v/DeepLesion/folder/50715173939)
# 
# The nhi deep leison dataset has the following files:
# 
# 
# key_slices - example slices of images along with label
# 
# DL_info.csv - a file with the labels of all the images
# 
# 
# images : They named each slice with the format “{patientindex}_{study index}_{series index}_{slice index}.png”, with the last underscore being / or \ to indicate sub-folders. The images are stored in unsigned 16 bit. One should subtract 32768 from the pixel intensity to obtain the original Hounsfield unit (HU) values. We provide not only the key CT slice that contains the lesion annotation, but also its 3D context (30mm extra slices above and below the key slice).
# 
# 
# 
# 

# In[116]:


import os
from PIL import Image
import pandas as pd
import cv2
import imageio
import os
import zipfile
import matplotlib.pyplot as plt


# I ran the "DL_save_nifti.py" file to get the nii files from the images which are stored in unsigned 16 bit format, then I sliced the nii file as shown below.

# In[117]:


vol = imageio.volread('000001_01_01_103-115.nii')


# In[118]:


vol.shape


# Doubt : The dataset gives 16 bit files and the code to get the nii file out of it, it has labels for each sliced image file. The file '000001_01_01_103-115.nii' is made of thirteen 16 bit files( also has depth of 13 and we can get 13 slices of image out of it). So technically each slice should be of the same order and we should  assign the labels to each slice respectively, but I am not really sure about it 
# 
# 

# In[119]:


fig,axes = plt.subplots(nrows=1,ncols=3)
axes[0].imshow(vol[0],cmap = "bone")
axes[1].imshow(vol[0],cmap = "gray")
axes[2].imshow(vol[0],cmap = "gray")
#axes[3].imshow(vol[3],cmap = "gray")
for ax in axes:
    ax.axis("off")
plt.show()


# In[120]:


for ii in range(1,10):
    if ii == 9: # To take the 9th slice and compare it with the '000001_01_01_109.png' example file present in the key slices
    
        im = vol[ii,:,:]
        imageio.imwrite("sliced_image_000001_01_01_109.jpg",im)

        print("image shape",im.shape)
       



# I saved the sliced image as "sliced_image_000001_01_01_109.jpg" which corresponds to the slice image example shown  [below](#original_image) which was taken from the file key_slices present in the dataset

# In[121]:


k = 'sliced_image_000001_01_01_109.jpg'


# In[122]:


im = Image.open(k)
imt = cv2.imread(k)
imt.shape


# In[123]:


im


# In[124]:


im.info


# I tried to change the resolution of image and save it as "test_600.png"

# In[125]:


im.save("test-600.jpg", dpi=(10,10))
#im.show()


# In[126]:


im = Image.open('test-600.jpg')
im.info


# ### I am even able to increase the dpi, is it the correct way to change the resolution of image?

# In[127]:


im.size


# I tried to get the bounding box co-ordinates of the image '000001_01_01_109.png'

# In[128]:


df = pd.read_csv("DL_info (1).csv")
df.head()


# In[129]:


ks = list(df["File_name"])


# In[130]:


for i,j in enumerate(ks) :
    if j == k:
        print(i)


# In[131]:


bounding_box = list(df["Bounding_boxes"])
m = bounding_box[0] 


# In[132]:


j = m.split(",")


# In[133]:


hs = []
for i in j:
    hs.append(float(i))


# In[134]:


hs #bounding box co-ordinates


# In[135]:


import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image
import numpy as np

im = np.array(Image.open('sliced_image_000001_01_01_109.jpg'), dtype=np.uint8)

# Create figure and axes
fig,ax = plt.subplots(1)

# Display the image
ax.imshow(im)

# Create a Rectangle patch
rect = patches.Rectangle((hs[0] , hs[1] ), hs[2]-hs[0] , hs[3] - hs[1] ,linewidth=1,edgecolor='r',facecolor='none')
#0.3087787109375, 0.34495019531250004, -0.26591523437500003, -0.252490234375
# Add the patch to the Axes
ax.add_patch(rect)
plt.savefig("toot.png")
plt.show()
[226.169, 90.0204, 241.252, 111.977]


# In[136]:


im.shape


# The above plot is obtained from the sliced image 

# <a id="original_image"></a>

# In[137]:


#im = Image.open(k)

imt = Image.open('000001_01_01_109.png')
#imt.shape
imt


# The above image is taken from the file key_slice, which has example images.

# In[138]:


import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image
import numpy as np

im = np.array(Image.open('000001_01_01_109.png'), dtype=np.uint8)

# Create figure and axes
fig,ax = plt.subplots(1)

# Display the image
ax.imshow(im)

# Create a Rectangle patch
rect = patches.Rectangle((hs[0] , hs[1] ), hs[2]-hs[0] , hs[3] - hs[1] ,linewidth=1,edgecolor='r',facecolor='none')
#0.3087787109375, 0.34495019531250004, -0.26591523437500003, -0.252490234375
# Add the patch to the Axes
ax.add_patch(rect)

plt.show()
#[226.169, 90.0204, 241.252, 111.977]


# The above plot has green bounding box which is already in the image, and red bounding box based on the label provided
